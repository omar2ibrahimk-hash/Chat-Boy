const $ = id => document.getElementById(id);
const USERS_KEY = "chatsphere_users_v1";
const SESSION_KEY = "chatsphere_session_v1";
const CHATS_KEY = "chatsphere_chats_v1";

let mode = "login";
let currentChatId = null;

const getJSON = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));

function currentUser(){ return getJSON(SESSION_KEY, null); }
function users(){ return getJSON(USERS_KEY, []); }
function chats(){ return getJSON(CHATS_KEY, {}); }
function setChats(v){ save(CHATS_KEY,v); }

function showAuth(){
  $("authView").classList.remove("hidden"); $("chatView").classList.add("hidden");
  $("userArea").innerHTML = "";
}
function showChat(){
  const user=currentUser(); if(!user){showAuth();return;}
  $("authView").classList.add("hidden"); $("chatView").classList.remove("hidden");
  $("userArea").innerHTML = `<span>${escapeHTML(user.email)}</span><button id="logout">Logout</button>`;
  $("logout").onclick=()=>{localStorage.removeItem(SESSION_KEY);currentChatId=null;showAuth();};
  loadChats();
}

function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

document.querySelectorAll(".tab").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active")); btn.classList.add("active");
  mode=btn.dataset.mode; $("authSubmit").textContent=mode==="login"?"Login":"Create account"; $("authMessage").textContent="";
});

$("authForm").onsubmit=e=>{
  e.preventDefault(); const email=$("email").value.trim().toLowerCase(), password=$("password").value;
  let list=users();
  if(mode==="signup"){
    if(list.some(u=>u.email===email)) return $("authMessage").textContent="An account with this email already exists.";
    list.push({email,password}); save(USERS_KEY,list); save(SESSION_KEY,{email}); showChat(); newChat();
  }else{
    const u=list.find(x=>x.email===email && x.password===password);
    if(!u) return $("authMessage").textContent="Incorrect email or password.";
    save(SESSION_KEY,{email}); showChat();
  }
};

function loadChats(){
  const user=currentUser(), all=chats(), mine=all[user.email]||[];
  $("chatList").innerHTML=mine.map(c=>`<button class="chat-item ${c.id===currentChatId?"active":""}" data-id="${c.id}">${escapeHTML(c.title||"New conversation")}</button>`).join("");
  document.querySelectorAll(".chat-item").forEach(b=>b.onclick=()=>openChat(b.dataset.id));
  if(!currentChatId && mine.length) openChat(mine[0].id);
  else if(!mine.length) newChat();
}
function newChat(){
  const user=currentUser(); if(!user)return;
  const all=chats(); all[user.email]??=[];
  const c={id:crypto.randomUUID(),title:"New conversation",messages:[]};
  all[user.email].unshift(c);setChats(all);currentChatId=c.id;renderChat(c);loadChats();
}
$("newChat").onclick=newChat;

function openChat(id){
  const user=currentUser(), c=(chats()[user.email]||[]).find(x=>x.id===id);
  if(!c)return; currentChatId=id; renderChat(c); loadChats();
}
function activeChat(){
  const user=currentUser(); return (chats()[user.email]||[]).find(x=>x.id===currentChatId);
}
function renderChat(c){
  $("chatTitle").textContent=c.title||"New conversation";
  $("messages").innerHTML=c.messages.length?c.messages.map(m=>messageHTML(m)).join(""):`<div class="welcome"><h3>How can I help?</h3><p>Ask a question and ChatSphere will reply.</p></div>`;
  $("messages").scrollTop=$("messages").scrollHeight;
}
function messageHTML(m){
  return `<div class="msg ${m.role}"><div class="avatar">${m.role==="user"?"You":"✦"}</div><div class="bubble">${escapeHTML(m.text)}</div></div>`;
}

$("messageForm").onsubmit=async e=>{
  e.preventDefault(); const input=$("messageInput"), text=input.value.trim(); if(!text)return;
  let c=activeChat(); if(!c)return;
  c.messages.push({role:"user",text}); if(c.title==="New conversation")c.title=text.slice(0,35);
  persistActive(c); renderChat(c); input.value="";
  $("sendButton").disabled=true;
  await new Promise(r=>setTimeout(r,500));
  const reply=botReply(text);
  c=activeChat(); c.messages.push({role:"assistant",text:reply}); persistActive(c); renderChat(c); $("sendButton").disabled=false;
};
$("messageInput").addEventListener("input",()=>{const x=$("messageInput");x.style.height="auto";x.style.height=Math.min(x.scrollHeight,140)+"px"});
$("clearChats").onclick=()=>{if(confirm("Delete all conversations on this device?")){const u=currentUser(),a=chats();a[u.email]=[];setChats(a);currentChatId=null;loadChats();}};

function persistActive(c){
  const u=currentUser(),a=chats(); a[u.email]=a[u.email]||[]; const i=a[u.email].findIndex(x=>x.id===c.id);
  if(i>=0)a[u.email][i]=c; else a[u.email].unshift(c);setChats(a);
}

function botReply(t){
  const x=t.toLowerCase();
  if(/\b(hi|hello|hey)\b/.test(x)) return "Hello! 👋 I’m ChatSphere. What would you like to talk about?";
  if(x.includes("who are you")) return "I’m ChatSphere, a browser-based demo AI assistant.";
  if(x.includes("time")) return "I can’t read a reliable live clock in this demo, but your device clock can show the current time.";
  if(x.includes("help")) return "Sure! Ask me a question, explain a topic, brainstorm an idea, or ask for a simple calculation.";
  if(/[0-9]\s*[\+\-\*\/]\s*[0-9]/.test(t)){
    try{const expr=t.match(/-?\d+(?:\.\d+)?\s*[\+\-\*\/]\s*-?\d+(?:\.\d+)?/)[0]; return `The result is ${Function('"use strict";return ('+expr+')')()}.`;}catch{}
  }
  return `I received: “${t}”\n\nThis GitHub-ready version includes authentication, protected chat UI, conversation history, and a local demo response engine. To get real AI answers, connect this frontend to a secure backend/API.`;
}

if(currentUser()) showChat(); else showAuth();
