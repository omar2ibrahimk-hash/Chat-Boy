# ChatSphere AI — GitHub-ready chatbot

A responsive chatbot web app with:

- Login and account creation
- Logout
- Protected chat interface
- Multiple conversations
- Conversation history
- Local browser storage
- Mobile-friendly UI
- Demo response engine

## Run

Open `index.html` in a browser, or publish the repository with GitHub Pages.

## GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `app.js`, and `README.md`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save.
7. Your site will be available at:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

## Important security note

This version is a frontend demo. Passwords are stored in browser localStorage, so it is **not suitable for real production accounts**.

For a real production chatbot, use a backend authentication/database service such as Firebase or Supabase and keep any AI API key on the server, never inside `app.js`.
